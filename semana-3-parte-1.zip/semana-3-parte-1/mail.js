/* Crear usuario */
Ingresar.addEventListener("click", function(event) {
    event.preventDefault();

    if (document.getElementById("correo_electronico").value === "") {
        alert("Agrega una correo electronico");

    }

    if (document.getElementById("contraseña").value === "") {
        alert("Agrega una contraseña");
    }
});
/* Registro usuario  */
Guardar.addEventListener("click", function(event) {
    event.preventDefault();


    if (password === "") {
        alert("Agrega una contraseña");

    }

    else if (repite_Contraseña === "") {
        alert("Agrega una contraseña");
    }

    else if (password !== repite_Contraseña) {
        alert("Contraseñas distintas");
    }
});



/* ojo */

const contraseña = document.getElementById("password");
const ojo = document.querySelector(".bx");

ojo.addEventListener("click", e => {
    if (contraseña.type == "password") {
        contraseña.type = "text";
    } else {
        contraseña.type = "password";
    }
});
